-- MySQL dump 10.13  Distrib 8.4.11, for Linux (x86_64)
--
-- Host: localhost    Database: pipsnote
-- ------------------------------------------------------
-- Server version	8.4.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_audit_log`
--

DROP TABLE IF EXISTS `admin_audit_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_audit_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `action` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resource_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resource_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `changes` json DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_created` (`user_id`,`created_at`),
  KEY `idx_action` (`action`),
  KEY `idx_resource` (`resource_type`,`resource_id`),
  KEY `idx_created` (`created_at`),
  CONSTRAINT `admin_audit_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `admin_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_audit_log`
--

LOCK TABLES `admin_audit_log` WRITE;
/*!40000 ALTER TABLE `admin_audit_log` DISABLE KEYS */;
INSERT INTO `admin_audit_log` VALUES (1,1,'refresh_market_data','market_data_symbol',NULL,'{\"failed\": [], \"succeeded\": [\"EUR/USD\", \"GBP/USD\", \"USD/JPY\", \"USD/CHF\", \"AUD/USD\", \"USD/CAD\", \"NZD/USD\", \"XAU/USD\", \"XAG/USD\", \"BTC/USD\", \"ETH/USD\", \"AAPL\", \"TSLA\", \"MSFT\"]}','113.190.92.129','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','2026-08-29 08:39:58'),(2,1,'update_settings','site_settings',NULL,'{\"bg.hero\": {\"after\": \"/images/backgrounds/gold-oil-cash-coins.jpg\", \"before\": \"\"}, \"theme.bg\": {\"after\": \"#0B0E14\", \"before\": \"#0B0E14\"}, \"theme.up\": {\"after\": \"#17C879\", \"before\": \"#17C879\"}, \"bg.global\": {\"after\": \"/images/backgrounds/gold-oil-cash-coins.jpg\", \"before\": \"\"}, \"bg.ticker\": {\"after\": \"/images/backgrounds/gold-oil-cash-coins.jpg\", \"before\": \"\"}, \"theme.ink\": {\"after\": \"#E8EBF2\", \"before\": \"#E8EBF2\"}, \"theme.red\": {\"after\": \"#FFB020\", \"before\": \"#FFB020\"}, \"theme.down\": {\"after\": \"#F0455C\", \"before\": \"#F0455C\"}, \"bg.newsletter\": {\"after\": \"/images/backgrounds/gold-oil-cash-coins.jpg\", \"before\": \"\"}, \"theme.gray_bg\": {\"after\": \"#131721\", \"before\": \"#131721\"}, \"theme.gray_mid\": {\"after\": \"#8891A6\", \"before\": \"#8891A6\"}, \"theme.red_dark\": {\"after\": \"#D68F0C\", \"before\": \"#D68F0C\"}, \"theme.gray_line\": {\"after\": \"#232A38\", \"before\": \"#232A38\"}, \"layout.site_name\": {\"after\": \"PIPSNOTE\", \"before\": \"PIPSNOTE\"}, \"layout.show_ticker\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.dark_default\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.surface_dark\": {\"after\": \"#05070A\", \"before\": \"#05070A\"}, \"layout.hero_variant\": {\"after\": \"editorial\", \"before\": \"editorial\"}}','113.190.92.129','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','2026-08-29 08:41:00'),(3,1,'update_settings','site_settings',NULL,'{\"bg.hero\": {\"after\": \"\", \"before\": \"/images/backgrounds/gold-oil-cash-coins.jpg\"}, \"theme.bg\": {\"after\": \"#0B0E14\", \"before\": \"#0B0E14\"}, \"theme.up\": {\"after\": \"#17C879\", \"before\": \"#17C879\"}, \"bg.global\": {\"after\": \"\", \"before\": \"/images/backgrounds/gold-oil-cash-coins.jpg\"}, \"bg.ticker\": {\"after\": \"\", \"before\": \"/images/backgrounds/gold-oil-cash-coins.jpg\"}, \"theme.ink\": {\"after\": \"#E8EBF2\", \"before\": \"#E8EBF2\"}, \"theme.red\": {\"after\": \"#FFB020\", \"before\": \"#FFB020\"}, \"theme.down\": {\"after\": \"#F0455C\", \"before\": \"#F0455C\"}, \"bg.newsletter\": {\"after\": \"\", \"before\": \"/images/backgrounds/gold-oil-cash-coins.jpg\"}, \"theme.gray_bg\": {\"after\": \"#131721\", \"before\": \"#131721\"}, \"theme.gray_mid\": {\"after\": \"#8891A6\", \"before\": \"#8891A6\"}, \"theme.red_dark\": {\"after\": \"#D68F0C\", \"before\": \"#D68F0C\"}, \"theme.gray_line\": {\"after\": \"#232A38\", \"before\": \"#232A38\"}, \"layout.site_name\": {\"after\": \"PIPSNOTE\", \"before\": \"PIPSNOTE\"}, \"layout.show_ticker\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.dark_default\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.surface_dark\": {\"after\": \"#05070A\", \"before\": \"#05070A\"}, \"layout.hero_variant\": {\"after\": \"editorial\", \"before\": \"editorial\"}}','113.190.92.129','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36','2026-08-29 08:41:28'),(4,1,'update_settings','site_settings',NULL,'{\"bg.hero\": {\"after\": \"\", \"before\": \"\"}, \"theme.bg\": {\"after\": \"#0B0E14\", \"before\": \"#0B0E14\"}, \"theme.up\": {\"after\": \"#17C879\", \"before\": \"#17C879\"}, \"bg.global\": {\"after\": \"/images/backgrounds/gold-oil-cash-coins.jpg\", \"before\": \"\"}, \"bg.ticker\": {\"after\": \"\", \"before\": \"\"}, \"theme.ink\": {\"after\": \"#E8EBF2\", \"before\": \"#E8EBF2\"}, \"theme.red\": {\"after\": \"#FFB020\", \"before\": \"#FFB020\"}, \"theme.down\": {\"after\": \"#F0455C\", \"before\": \"#F0455C\"}, \"bg.newsletter\": {\"after\": \"\", \"before\": \"\"}, \"theme.gray_bg\": {\"after\": \"#131721\", \"before\": \"#131721\"}, \"theme.gray_mid\": {\"after\": \"#8891A6\", \"before\": \"#8891A6\"}, \"theme.red_dark\": {\"after\": \"#D68F0C\", \"before\": \"#D68F0C\"}, \"theme.gray_line\": {\"after\": \"#232A38\", \"before\": \"#232A38\"}, \"layout.site_name\": {\"after\": \"PIPSNOTE\", \"before\": \"PIPSNOTE\"}, \"layout.show_ticker\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.dark_default\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.surface_dark\": {\"after\": \"#05070A\", \"before\": \"#05070A\"}, \"layout.hero_variant\": {\"after\": \"editorial\", \"before\": \"editorial\"}}','113.168.65.85','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2026-08-29 09:27:16'),(5,1,'update_settings','site_settings',NULL,'{\"bg.hero\": {\"after\": \"\", \"before\": \"\"}, \"theme.bg\": {\"after\": \"#0B0E14\", \"before\": \"#0B0E14\"}, \"theme.up\": {\"after\": \"#17C879\", \"before\": \"#17C879\"}, \"bg.global\": {\"after\": \"/images/backgrounds/candlestick-uptrend-blue.jpg\", \"before\": \"/images/backgrounds/gold-oil-cash-coins.jpg\"}, \"bg.ticker\": {\"after\": \"\", \"before\": \"\"}, \"theme.ink\": {\"after\": \"#E8EBF2\", \"before\": \"#E8EBF2\"}, \"theme.red\": {\"after\": \"#FFB020\", \"before\": \"#FFB020\"}, \"theme.down\": {\"after\": \"#F0455C\", \"before\": \"#F0455C\"}, \"bg.newsletter\": {\"after\": \"\", \"before\": \"\"}, \"theme.gray_bg\": {\"after\": \"#131721\", \"before\": \"#131721\"}, \"theme.gray_mid\": {\"after\": \"#8891A6\", \"before\": \"#8891A6\"}, \"theme.red_dark\": {\"after\": \"#D68F0C\", \"before\": \"#D68F0C\"}, \"theme.gray_line\": {\"after\": \"#232A38\", \"before\": \"#232A38\"}, \"layout.site_name\": {\"after\": \"PIPSNOTE\", \"before\": \"PIPSNOTE\"}, \"layout.show_ticker\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.dark_default\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.surface_dark\": {\"after\": \"#05070A\", \"before\": \"#05070A\"}, \"layout.hero_variant\": {\"after\": \"editorial\", \"before\": \"editorial\"}}','113.168.65.85','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2026-08-29 09:27:50'),(6,1,'apply_preset','site_settings',NULL,'{\"diff\": {\"theme.bg\": {\"after\": \"#0A0F1A\", \"before\": \"#0B0E14\"}, \"theme.up\": {\"after\": \"#22C55E\", \"before\": \"#17C879\"}, \"theme.ink\": {\"after\": \"#E6EEF7\", \"before\": \"#E8EBF2\"}, \"theme.red\": {\"after\": \"#2E8BFF\", \"before\": \"#FFB020\"}, \"theme.down\": {\"after\": \"#EF4444\", \"before\": \"#F0455C\"}, \"theme.gray_bg\": {\"after\": \"#111826\", \"before\": \"#131721\"}, \"theme.gray_mid\": {\"after\": \"#7C8BA8\", \"before\": \"#8891A6\"}, \"theme.red_dark\": {\"after\": \"#1D63C9\", \"before\": \"#D68F0C\"}, \"theme.gray_line\": {\"after\": \"#22304A\", \"before\": \"#232A38\"}, \"theme.dark_default\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.surface_dark\": {\"after\": \"#05080F\", \"before\": \"#05070A\"}}, \"preset\": \"blue\"}','113.168.65.85','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2026-08-29 09:28:12'),(7,1,'update_settings','site_settings',NULL,'{\"bg.hero\": {\"after\": \"\", \"before\": \"\"}, \"theme.bg\": {\"after\": \"#0A0F1A\", \"before\": \"#0A0F1A\"}, \"theme.up\": {\"after\": \"#22C55E\", \"before\": \"#22C55E\"}, \"bg.global\": {\"after\": \"/images/backgrounds/candlestick-uptrend-blue.jpg\", \"before\": \"/images/backgrounds/candlestick-uptrend-blue.jpg\"}, \"bg.ticker\": {\"after\": \"\", \"before\": \"\"}, \"theme.ink\": {\"after\": \"#E6EEF7\", \"before\": \"#E6EEF7\"}, \"theme.red\": {\"after\": \"#2E8BFF\", \"before\": \"#2E8BFF\"}, \"theme.down\": {\"after\": \"#EF4444\", \"before\": \"#EF4444\"}, \"bg.newsletter\": {\"after\": \"\", \"before\": \"\"}, \"theme.gray_bg\": {\"after\": \"#111826\", \"before\": \"#111826\"}, \"theme.gray_mid\": {\"after\": \"#7C8BA8\", \"before\": \"#7C8BA8\"}, \"theme.red_dark\": {\"after\": \"#1D63C9\", \"before\": \"#1D63C9\"}, \"theme.gray_line\": {\"after\": \"#22304A\", \"before\": \"#22304A\"}, \"layout.site_name\": {\"after\": \"PIPSNOTE\", \"before\": \"PIPSNOTE\"}, \"layout.show_ticker\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.dark_default\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.surface_dark\": {\"after\": \"#05080F\", \"before\": \"#05080F\"}, \"layout.hero_variant\": {\"after\": \"editorial\", \"before\": \"editorial\"}}','113.168.65.85','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2026-08-29 09:28:13'),(8,1,'update_settings','site_settings',NULL,'{\"bg.hero\": {\"after\": \"\", \"before\": \"\"}, \"theme.bg\": {\"after\": \"#0A0F1A\", \"before\": \"#0A0F1A\"}, \"theme.up\": {\"after\": \"#22C55E\", \"before\": \"#22C55E\"}, \"bg.global\": {\"after\": \"/images/backgrounds/candlestick-uptrend-blue.jpg\", \"before\": \"/images/backgrounds/candlestick-uptrend-blue.jpg\"}, \"bg.ticker\": {\"after\": \"\", \"before\": \"\"}, \"theme.ink\": {\"after\": \"#E6EEF7\", \"before\": \"#E6EEF7\"}, \"theme.red\": {\"after\": \"#2E8BFF\", \"before\": \"#2E8BFF\"}, \"theme.down\": {\"after\": \"#ed0c0c\", \"before\": \"#EF4444\"}, \"bg.newsletter\": {\"after\": \"\", \"before\": \"\"}, \"theme.gray_bg\": {\"after\": \"#111826\", \"before\": \"#111826\"}, \"theme.gray_mid\": {\"after\": \"#7C8BA8\", \"before\": \"#7C8BA8\"}, \"theme.red_dark\": {\"after\": \"#1D63C9\", \"before\": \"#1D63C9\"}, \"theme.gray_line\": {\"after\": \"#22304A\", \"before\": \"#22304A\"}, \"layout.site_name\": {\"after\": \"PIPSNOTE\", \"before\": \"PIPSNOTE\"}, \"layout.show_ticker\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.dark_default\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.surface_dark\": {\"after\": \"#05080F\", \"before\": \"#05080F\"}, \"layout.hero_variant\": {\"after\": \"editorial\", \"before\": \"editorial\"}}','113.168.65.85','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2026-08-29 09:28:31'),(9,1,'apply_preset','site_settings',NULL,'{\"diff\": {\"theme.bg\": {\"after\": \"#0A0F1A\", \"before\": \"#0A0F1A\"}, \"theme.up\": {\"after\": \"#22C55E\", \"before\": \"#22C55E\"}, \"theme.ink\": {\"after\": \"#E6EEF7\", \"before\": \"#E6EEF7\"}, \"theme.red\": {\"after\": \"#2E8BFF\", \"before\": \"#2E8BFF\"}, \"theme.down\": {\"after\": \"#EF4444\", \"before\": \"#ed0c0c\"}, \"theme.gray_bg\": {\"after\": \"#111826\", \"before\": \"#111826\"}, \"theme.gray_mid\": {\"after\": \"#7C8BA8\", \"before\": \"#7C8BA8\"}, \"theme.red_dark\": {\"after\": \"#1D63C9\", \"before\": \"#1D63C9\"}, \"theme.gray_line\": {\"after\": \"#22304A\", \"before\": \"#22304A\"}, \"theme.dark_default\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.surface_dark\": {\"after\": \"#05080F\", \"before\": \"#05080F\"}}, \"preset\": \"blue\"}','113.168.65.85','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2026-08-29 09:28:58'),(10,1,'update_settings','site_settings',NULL,'{\"bg.hero\": {\"after\": \"\", \"before\": \"\"}, \"theme.bg\": {\"after\": \"#0A0F1A\", \"before\": \"#0A0F1A\"}, \"theme.up\": {\"after\": \"#22C55E\", \"before\": \"#22C55E\"}, \"bg.global\": {\"after\": \"/images/backgrounds/candlestick-uptrend-blue.jpg\", \"before\": \"/images/backgrounds/candlestick-uptrend-blue.jpg\"}, \"bg.ticker\": {\"after\": \"\", \"before\": \"\"}, \"theme.ink\": {\"after\": \"#E6EEF7\", \"before\": \"#E6EEF7\"}, \"theme.red\": {\"after\": \"#2E8BFF\", \"before\": \"#2E8BFF\"}, \"theme.down\": {\"after\": \"#EF4444\", \"before\": \"#EF4444\"}, \"bg.newsletter\": {\"after\": \"\", \"before\": \"\"}, \"theme.gray_bg\": {\"after\": \"#111826\", \"before\": \"#111826\"}, \"theme.gray_mid\": {\"after\": \"#7C8BA8\", \"before\": \"#7C8BA8\"}, \"theme.red_dark\": {\"after\": \"#1D63C9\", \"before\": \"#1D63C9\"}, \"theme.gray_line\": {\"after\": \"#22304A\", \"before\": \"#22304A\"}, \"layout.site_name\": {\"after\": \"PIPSNOTE\", \"before\": \"PIPSNOTE\"}, \"layout.show_ticker\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.dark_default\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.surface_dark\": {\"after\": \"#05080F\", \"before\": \"#05080F\"}, \"layout.hero_variant\": {\"after\": \"editorial\", \"before\": \"editorial\"}}','113.168.65.85','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2026-08-29 09:28:59'),(11,1,'update_settings','site_settings',NULL,'{\"bg.hero\": {\"after\": \"\", \"before\": \"\"}, \"theme.bg\": {\"after\": \"#0A0F1A\", \"before\": \"#0A0F1A\"}, \"theme.up\": {\"after\": \"#22C55E\", \"before\": \"#22C55E\"}, \"bg.global\": {\"after\": \"\", \"before\": \"/images/backgrounds/candlestick-uptrend-blue.jpg\"}, \"bg.ticker\": {\"after\": \"\", \"before\": \"\"}, \"theme.ink\": {\"after\": \"#E6EEF7\", \"before\": \"#E6EEF7\"}, \"theme.red\": {\"after\": \"#2E8BFF\", \"before\": \"#2E8BFF\"}, \"theme.down\": {\"after\": \"#EF4444\", \"before\": \"#EF4444\"}, \"bg.newsletter\": {\"after\": \"\", \"before\": \"\"}, \"theme.gray_bg\": {\"after\": \"#111826\", \"before\": \"#111826\"}, \"theme.gray_mid\": {\"after\": \"#7C8BA8\", \"before\": \"#7C8BA8\"}, \"theme.red_dark\": {\"after\": \"#1D63C9\", \"before\": \"#1D63C9\"}, \"theme.gray_line\": {\"after\": \"#22304A\", \"before\": \"#22304A\"}, \"layout.site_name\": {\"after\": \"PIPSNOTE\", \"before\": \"PIPSNOTE\"}, \"layout.show_ticker\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.dark_default\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.surface_dark\": {\"after\": \"#05080F\", \"before\": \"#05080F\"}, \"layout.hero_variant\": {\"after\": \"editorial\", \"before\": \"editorial\"}}','113.168.65.85','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2026-08-29 09:29:10'),(12,1,'apply_preset','site_settings',NULL,'{\"diff\": {\"theme.bg\": {\"after\": \"#0A0F1A\", \"before\": \"#0A0F1A\"}, \"theme.up\": {\"after\": \"#22C55E\", \"before\": \"#22C55E\"}, \"theme.ink\": {\"after\": \"#E6EEF7\", \"before\": \"#E6EEF7\"}, \"theme.red\": {\"after\": \"#2E8BFF\", \"before\": \"#2E8BFF\"}, \"theme.down\": {\"after\": \"#EF4444\", \"before\": \"#EF4444\"}, \"theme.gray_bg\": {\"after\": \"#111826\", \"before\": \"#111826\"}, \"theme.gray_mid\": {\"after\": \"#7C8BA8\", \"before\": \"#7C8BA8\"}, \"theme.red_dark\": {\"after\": \"#1D63C9\", \"before\": \"#1D63C9\"}, \"theme.gray_line\": {\"after\": \"#22304A\", \"before\": \"#22304A\"}, \"theme.dark_default\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.surface_dark\": {\"after\": \"#05080F\", \"before\": \"#05080F\"}}, \"preset\": \"blue\"}','113.168.65.85','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2026-08-29 09:29:21'),(13,1,'apply_preset','site_settings',NULL,'{\"diff\": {\"theme.bg\": {\"after\": \"#0C0A14\", \"before\": \"#0A0F1A\"}, \"theme.up\": {\"after\": \"#14E8A0\", \"before\": \"#22C55E\"}, \"theme.ink\": {\"after\": \"#F1EEFB\", \"before\": \"#E6EEF7\"}, \"theme.red\": {\"after\": \"#B14EFF\", \"before\": \"#2E8BFF\"}, \"theme.down\": {\"after\": \"#FF3D6E\", \"before\": \"#EF4444\"}, \"theme.gray_bg\": {\"after\": \"#171325\", \"before\": \"#111826\"}, \"theme.gray_mid\": {\"after\": \"#9089AC\", \"before\": \"#7C8BA8\"}, \"theme.red_dark\": {\"after\": \"#8F2FE0\", \"before\": \"#1D63C9\"}, \"theme.gray_line\": {\"after\": \"#2C2440\", \"before\": \"#22304A\"}, \"theme.dark_default\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.surface_dark\": {\"after\": \"#050307\", \"before\": \"#05080F\"}}, \"preset\": \"neon\"}','113.168.65.85','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2026-08-29 09:29:23'),(14,1,'update_settings','site_settings',NULL,'{\"bg.hero\": {\"after\": \"\", \"before\": \"\"}, \"theme.bg\": {\"after\": \"#0C0A14\", \"before\": \"#0C0A14\"}, \"theme.up\": {\"after\": \"#14E8A0\", \"before\": \"#14E8A0\"}, \"bg.global\": {\"after\": \"\", \"before\": \"\"}, \"bg.ticker\": {\"after\": \"\", \"before\": \"\"}, \"theme.ink\": {\"after\": \"#F1EEFB\", \"before\": \"#F1EEFB\"}, \"theme.red\": {\"after\": \"#B14EFF\", \"before\": \"#B14EFF\"}, \"theme.down\": {\"after\": \"#FF3D6E\", \"before\": \"#FF3D6E\"}, \"bg.newsletter\": {\"after\": \"\", \"before\": \"\"}, \"theme.gray_bg\": {\"after\": \"#171325\", \"before\": \"#171325\"}, \"theme.gray_mid\": {\"after\": \"#9089AC\", \"before\": \"#9089AC\"}, \"theme.red_dark\": {\"after\": \"#8F2FE0\", \"before\": \"#8F2FE0\"}, \"theme.gray_line\": {\"after\": \"#2C2440\", \"before\": \"#2C2440\"}, \"layout.site_name\": {\"after\": \"PIPSNOTE\", \"before\": \"PIPSNOTE\"}, \"layout.show_ticker\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.dark_default\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.surface_dark\": {\"after\": \"#050307\", \"before\": \"#050307\"}, \"layout.hero_variant\": {\"after\": \"editorial\", \"before\": \"editorial\"}}','113.168.65.85','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2026-08-29 09:29:26'),(15,1,'apply_preset','site_settings',NULL,'{\"diff\": {\"theme.bg\": {\"after\": \"#0A0F1A\", \"before\": \"#0C0A14\"}, \"theme.up\": {\"after\": \"#22C55E\", \"before\": \"#14E8A0\"}, \"theme.ink\": {\"after\": \"#E6EEF7\", \"before\": \"#F1EEFB\"}, \"theme.red\": {\"after\": \"#2E8BFF\", \"before\": \"#B14EFF\"}, \"theme.down\": {\"after\": \"#EF4444\", \"before\": \"#FF3D6E\"}, \"theme.gray_bg\": {\"after\": \"#111826\", \"before\": \"#171325\"}, \"theme.gray_mid\": {\"after\": \"#7C8BA8\", \"before\": \"#9089AC\"}, \"theme.red_dark\": {\"after\": \"#1D63C9\", \"before\": \"#8F2FE0\"}, \"theme.gray_line\": {\"after\": \"#22304A\", \"before\": \"#2C2440\"}, \"theme.dark_default\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.surface_dark\": {\"after\": \"#05080F\", \"before\": \"#050307\"}}, \"preset\": \"blue\"}','113.168.65.85','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2026-08-29 09:30:20'),(16,1,'update_settings','site_settings',NULL,'{\"bg.hero\": {\"after\": \"\", \"before\": \"\"}, \"theme.bg\": {\"after\": \"#0A0F1A\", \"before\": \"#0A0F1A\"}, \"theme.up\": {\"after\": \"#22C55E\", \"before\": \"#22C55E\"}, \"bg.global\": {\"after\": \"\", \"before\": \"\"}, \"bg.ticker\": {\"after\": \"\", \"before\": \"\"}, \"theme.ink\": {\"after\": \"#E6EEF7\", \"before\": \"#E6EEF7\"}, \"theme.red\": {\"after\": \"#2E8BFF\", \"before\": \"#2E8BFF\"}, \"theme.down\": {\"after\": \"#EF4444\", \"before\": \"#EF4444\"}, \"bg.newsletter\": {\"after\": \"\", \"before\": \"\"}, \"theme.gray_bg\": {\"after\": \"#111826\", \"before\": \"#111826\"}, \"theme.gray_mid\": {\"after\": \"#7C8BA8\", \"before\": \"#7C8BA8\"}, \"theme.red_dark\": {\"after\": \"#1D63C9\", \"before\": \"#1D63C9\"}, \"theme.gray_line\": {\"after\": \"#22304A\", \"before\": \"#22304A\"}, \"layout.site_name\": {\"after\": \"PIPSNOTE\", \"before\": \"PIPSNOTE\"}, \"layout.show_ticker\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.dark_default\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.surface_dark\": {\"after\": \"#05080F\", \"before\": \"#05080F\"}, \"layout.hero_variant\": {\"after\": \"editorial\", \"before\": \"editorial\"}}','113.168.65.85','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2026-08-29 09:30:20'),(17,1,'apply_preset','site_settings',NULL,'{\"diff\": {\"theme.bg\": {\"after\": \"#0C0A14\", \"before\": \"#0A0F1A\"}, \"theme.up\": {\"after\": \"#14E8A0\", \"before\": \"#22C55E\"}, \"theme.ink\": {\"after\": \"#F1EEFB\", \"before\": \"#E6EEF7\"}, \"theme.red\": {\"after\": \"#B14EFF\", \"before\": \"#2E8BFF\"}, \"theme.down\": {\"after\": \"#FF3D6E\", \"before\": \"#EF4444\"}, \"theme.gray_bg\": {\"after\": \"#171325\", \"before\": \"#111826\"}, \"theme.gray_mid\": {\"after\": \"#9089AC\", \"before\": \"#7C8BA8\"}, \"theme.red_dark\": {\"after\": \"#8F2FE0\", \"before\": \"#1D63C9\"}, \"theme.gray_line\": {\"after\": \"#2C2440\", \"before\": \"#22304A\"}, \"theme.dark_default\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.surface_dark\": {\"after\": \"#050307\", \"before\": \"#05080F\"}}, \"preset\": \"neon\"}','113.168.65.85','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2026-08-29 09:33:27'),(18,1,'update_settings','site_settings',NULL,'{\"bg.hero\": {\"after\": \"\", \"before\": \"\"}, \"theme.bg\": {\"after\": \"#0C0A14\", \"before\": \"#0C0A14\"}, \"theme.up\": {\"after\": \"#14E8A0\", \"before\": \"#14E8A0\"}, \"bg.global\": {\"after\": \"\", \"before\": \"\"}, \"bg.ticker\": {\"after\": \"\", \"before\": \"\"}, \"theme.ink\": {\"after\": \"#F1EEFB\", \"before\": \"#F1EEFB\"}, \"theme.red\": {\"after\": \"#B14EFF\", \"before\": \"#B14EFF\"}, \"theme.down\": {\"after\": \"#FF3D6E\", \"before\": \"#FF3D6E\"}, \"bg.newsletter\": {\"after\": \"\", \"before\": \"\"}, \"theme.gray_bg\": {\"after\": \"#171325\", \"before\": \"#171325\"}, \"theme.gray_mid\": {\"after\": \"#9089AC\", \"before\": \"#9089AC\"}, \"theme.red_dark\": {\"after\": \"#8F2FE0\", \"before\": \"#8F2FE0\"}, \"theme.gray_line\": {\"after\": \"#2C2440\", \"before\": \"#2C2440\"}, \"layout.site_name\": {\"after\": \"PIPSNOTE\", \"before\": \"PIPSNOTE\"}, \"layout.show_ticker\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.dark_default\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.surface_dark\": {\"after\": \"#050307\", \"before\": \"#050307\"}, \"layout.hero_variant\": {\"after\": \"editorial\", \"before\": \"editorial\"}}','113.168.65.85','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2026-08-29 09:33:28'),(19,1,'apply_preset','site_settings',NULL,'{\"diff\": {\"theme.bg\": {\"after\": \"#0A0F1A\", \"before\": \"#0C0A14\"}, \"theme.up\": {\"after\": \"#22C55E\", \"before\": \"#14E8A0\"}, \"theme.ink\": {\"after\": \"#E6EEF7\", \"before\": \"#F1EEFB\"}, \"theme.red\": {\"after\": \"#2E8BFF\", \"before\": \"#B14EFF\"}, \"theme.down\": {\"after\": \"#EF4444\", \"before\": \"#FF3D6E\"}, \"theme.gray_bg\": {\"after\": \"#111826\", \"before\": \"#171325\"}, \"theme.gray_mid\": {\"after\": \"#7C8BA8\", \"before\": \"#9089AC\"}, \"theme.red_dark\": {\"after\": \"#1D63C9\", \"before\": \"#8F2FE0\"}, \"theme.gray_line\": {\"after\": \"#22304A\", \"before\": \"#2C2440\"}, \"theme.dark_default\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.surface_dark\": {\"after\": \"#05080F\", \"before\": \"#050307\"}}, \"preset\": \"blue\"}','113.168.65.85','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2026-08-29 09:33:32'),(20,1,'update_settings','site_settings',NULL,'{\"bg.hero\": {\"after\": \"\", \"before\": \"\"}, \"theme.bg\": {\"after\": \"#0A0F1A\", \"before\": \"#0A0F1A\"}, \"theme.up\": {\"after\": \"#22C55E\", \"before\": \"#22C55E\"}, \"bg.global\": {\"after\": \"\", \"before\": \"\"}, \"bg.ticker\": {\"after\": \"\", \"before\": \"\"}, \"theme.ink\": {\"after\": \"#E6EEF7\", \"before\": \"#E6EEF7\"}, \"theme.red\": {\"after\": \"#2E8BFF\", \"before\": \"#2E8BFF\"}, \"theme.down\": {\"after\": \"#EF4444\", \"before\": \"#EF4444\"}, \"bg.newsletter\": {\"after\": \"\", \"before\": \"\"}, \"theme.gray_bg\": {\"after\": \"#111826\", \"before\": \"#111826\"}, \"theme.gray_mid\": {\"after\": \"#7C8BA8\", \"before\": \"#7C8BA8\"}, \"theme.red_dark\": {\"after\": \"#1D63C9\", \"before\": \"#1D63C9\"}, \"theme.gray_line\": {\"after\": \"#22304A\", \"before\": \"#22304A\"}, \"layout.site_name\": {\"after\": \"PIPSNOTE\", \"before\": \"PIPSNOTE\"}, \"layout.show_ticker\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.dark_default\": {\"after\": \"true\", \"before\": \"true\"}, \"theme.surface_dark\": {\"after\": \"#05080F\", \"before\": \"#05080F\"}, \"layout.hero_variant\": {\"after\": \"editorial\", \"before\": \"editorial\"}}','113.168.65.85','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2026-08-29 09:33:33'),(21,1,'update_broker','broker','6','{\"name\": \"Exness\", \"slug\": \"exness\", \"type\": \"forex\", \"badge\": null, \"rating\": 4.6, \"leverage\": \"Unlimited\", \"logo_url\": \"https://seeklogo.com/vector-logo/359954/exness\", \"is_active\": true, \"description\": \"Đòn bẩy không giới hạn, rút tiền tức thời.\", \"is_featured\": false, \"min_deposit\": \"$1\", \"spread_from\": \"0.3 pip\", \"affiliate_url\": \"https://affiliate.example.com/exness\"}','113.168.65.85','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2026-08-29 09:35:41'),(22,1,'update_broker','broker','6','{\"name\": \"Exness\", \"slug\": \"exness\", \"type\": \"forex\", \"badge\": null, \"rating\": 4.6, \"leverage\": \"Unlimited\", \"logo_url\": \"https://seeklogo.com/vector-logo/359954/exness\", \"is_active\": true, \"description\": \"Đòn bẩy không giới hạn, rút tiền tức thời.\", \"is_featured\": true, \"min_deposit\": \"$1\", \"spread_from\": \"0.3 pip\", \"affiliate_url\": \"https://affiliate.example.com/exness\"}','113.168.65.85','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2026-08-29 09:36:24'),(23,1,'update_broker','broker','6','{\"name\": \"Exness\", \"slug\": \"exness\", \"type\": \"forex\", \"badge\": null, \"rating\": 4.6, \"leverage\": \"Unlimited\", \"logo_url\": null, \"is_active\": true, \"description\": \"Đòn bẩy không giới hạn, rút tiền tức thời.\", \"is_featured\": false, \"min_deposit\": \"$1\", \"spread_from\": \"0.3 pip\", \"affiliate_url\": \"https://affiliate.example.com/exness\"}','113.168.65.85','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2026-08-29 09:36:43');
/*!40000 ALTER TABLE `admin_audit_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_users`
--

DROP TABLE IF EXISTS `admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('superadmin','editor','author') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'author',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `last_login_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_username` (`username`),
  KEY `idx_email` (`email`),
  KEY `idx_role` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_users`
--

LOCK TABLES `admin_users` WRITE;
/*!40000 ALTER TABLE `admin_users` DISABLE KEYS */;
INSERT INTO `admin_users` VALUES (1,'admin','admin@pipsnote.local','$2b$10$rZeoO5lpkw8oP3FowcXKmuWOtmQw1N4EO/kiF4JeqpJBsGxG7A4va','superadmin',1,'2026-08-29 09:22:40','2026-08-29 08:31:08','2026-08-29 09:22:40');
/*!40000 ALTER TABLE `admin_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `affiliate_clicks`
--

DROP TABLE IF EXISTS `affiliate_clicks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `affiliate_clicks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `broker_id` int unsigned DEFAULT NULL,
  `post_id` int unsigned DEFAULT NULL,
  `ip_hash` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referrer` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `clicked_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_broker_clicked` (`broker_id`,`clicked_at`),
  KEY `idx_ip` (`ip_address`),
  KEY `idx_post` (`post_id`),
  CONSTRAINT `affiliate_clicks_ibfk_1` FOREIGN KEY (`broker_id`) REFERENCES `brokers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_affiliate_clicks_post` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `affiliate_clicks`
--

LOCK TABLES `affiliate_clicks` WRITE;
/*!40000 ALTER TABLE `affiliate_clicks` DISABLE KEYS */;
INSERT INTO `affiliate_clicks` VALUES (1,1,NULL,'58f8a363422d207ccf6effcf3ea7e9e2a87163d66292007de0a1a7acd735d2f8',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',NULL,'2026-08-29 08:38:44'),(2,3,NULL,'58f8a363422d207ccf6effcf3ea7e9e2a87163d66292007de0a1a7acd735d2f8',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',NULL,'2026-08-29 08:38:44'),(3,6,NULL,'58f8a363422d207ccf6effcf3ea7e9e2a87163d66292007de0a1a7acd735d2f8',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',NULL,'2026-08-29 08:38:44'),(4,5,NULL,'58f8a363422d207ccf6effcf3ea7e9e2a87163d66292007de0a1a7acd735d2f8',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',NULL,'2026-08-29 08:38:44'),(5,4,NULL,'58f8a363422d207ccf6effcf3ea7e9e2a87163d66292007de0a1a7acd735d2f8',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',NULL,'2026-08-29 08:38:44'),(6,2,NULL,'58f8a363422d207ccf6effcf3ea7e9e2a87163d66292007de0a1a7acd735d2f8',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',NULL,'2026-08-29 08:38:44'),(7,4,NULL,'14988b20cdbda426432ca648d6fa0c8abd27589f21657d7da848b8a9a15f4203',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',NULL,'2026-08-29 08:40:19'),(8,3,NULL,'14988b20cdbda426432ca648d6fa0c8abd27589f21657d7da848b8a9a15f4203',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',NULL,'2026-08-29 08:40:19'),(9,1,NULL,'14988b20cdbda426432ca648d6fa0c8abd27589f21657d7da848b8a9a15f4203',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',NULL,'2026-08-29 08:40:19'),(10,5,NULL,'14988b20cdbda426432ca648d6fa0c8abd27589f21657d7da848b8a9a15f4203',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',NULL,'2026-08-29 08:40:20'),(11,2,NULL,'14988b20cdbda426432ca648d6fa0c8abd27589f21657d7da848b8a9a15f4203',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',NULL,'2026-08-29 08:40:20'),(12,6,NULL,'14988b20cdbda426432ca648d6fa0c8abd27589f21657d7da848b8a9a15f4203',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',NULL,'2026-08-29 08:40:20'),(13,1,NULL,'eee87a47c500b4031714d3e1179e6e0bad94955676e07796eb7eab861e41f6ce',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',NULL,'2026-08-29 08:41:53'),(14,2,NULL,'eee87a47c500b4031714d3e1179e6e0bad94955676e07796eb7eab861e41f6ce',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',NULL,'2026-08-29 08:41:53'),(15,3,NULL,'eee87a47c500b4031714d3e1179e6e0bad94955676e07796eb7eab861e41f6ce',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',NULL,'2026-08-29 08:41:53'),(16,5,NULL,'eee87a47c500b4031714d3e1179e6e0bad94955676e07796eb7eab861e41f6ce',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',NULL,'2026-08-29 08:41:53'),(17,4,NULL,'eee87a47c500b4031714d3e1179e6e0bad94955676e07796eb7eab861e41f6ce',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',NULL,'2026-08-29 08:41:53'),(18,6,NULL,'eee87a47c500b4031714d3e1179e6e0bad94955676e07796eb7eab861e41f6ce',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',NULL,'2026-08-29 08:41:54'),(19,6,NULL,'624276cbee8f6bacfa89aae71fcf1d5bb3bca52cfaeb72044b57e6c8e3beea4d',NULL,'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','https://hoan.bhquan.store/','2026-08-29 09:35:46');
/*!40000 ALTER TABLE `affiliate_clicks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brokers`
--

DROP TABLE IF EXISTS `brokers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `brokers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(220) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('forex','crypto','stock','all') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'forex',
  `logo_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `badge` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `min_deposit` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `leverage` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `spread_from` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `affiliate_url` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rating` decimal(3,2) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int NOT NULL DEFAULT '0',
  `click_count` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_slug` (`slug`),
  KEY `idx_active_rating` (`is_active`,`rating`),
  KEY `idx_sort_order` (`sort_order`),
  CONSTRAINT `brokers_chk_1` CHECK (((`rating` >= 0) and (`rating` <= 5)))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brokers`
--

LOCK TABLES `brokers` WRITE;
/*!40000 ALTER TABLE `brokers` DISABLE KEYS */;
INSERT INTO `brokers` VALUES (1,'IC Markets','ic-markets','forex',NULL,'Sàn ECN nổi bật với spread cực thấp, phù hợp trader scalping và EA.','Hot','$200','1:500','0.0 pip','https://affiliate.example.com/ic-markets',4.70,1,1,1,3,'2026-08-29 08:31:11','2026-08-29 08:41:53'),(2,'XM','xm','forex',NULL,'Sàn phổ biến toàn cầu, nạp tối thiểu thấp, hỗ trợ đa ngôn ngữ.','Phổ biến','$5','1:1000','0.6 pip','https://affiliate.example.com/xm',4.50,1,1,2,3,'2026-08-29 08:31:11','2026-08-29 08:41:53'),(3,'VT Markets','vt-markets','forex',NULL,'Sàn mới nổi với spread cạnh tranh và tốc độ khớp lệnh nhanh.','Mới','$50','1:500','0.0 pip','https://affiliate.example.com/vt-markets',4.30,1,1,3,3,'2026-08-29 08:31:11','2026-08-29 08:41:53'),(4,'HFM','hfm','forex',NULL,'Đòn bẩy cao, nhiều chương trình bonus cho trader mới.','Bonus','$5','1:2000','0.2 pip','https://affiliate.example.com/hfm',4.20,1,0,4,3,'2026-08-29 08:31:11','2026-08-29 08:41:53'),(5,'Vantage','vantage','forex',NULL,'Sàn được quản lý đa quốc gia, spread thấp trên tài khoản Raw.',NULL,'$50','1:500','0.0 pip','https://affiliate.example.com/vantage',4.40,1,0,5,3,'2026-08-29 08:31:11','2026-08-29 08:41:53'),(6,'Exness','exness','forex',NULL,'Đòn bẩy không giới hạn, rút tiền tức thời.',NULL,'$1','Unlimited','0.3 pip','https://affiliate.example.com/exness',4.60,1,0,6,4,'2026-08-29 08:31:11','2026-08-29 09:36:43');
/*!40000 ALTER TABLE `brokers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `parent_id` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_parent` (`parent_id`),
  KEY `idx_slug` (`slug`),
  CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Kiến thức cơ bản','kien-thuc-co-ban','Kiến thức nền tảng cho trader mới bắt đầu',NULL,'2026-08-29 08:31:11','2026-08-29 08:31:11'),(2,'Phân tích kỹ thuật','phan-tich-ky-thuat','Phân tích biểu đồ, chỉ báo, mô hình giá',NULL,'2026-08-29 08:31:11','2026-08-29 08:31:11'),(3,'Tin tức thị trường','tin-tuc-thi-truong','Cập nhật tin tức và sự kiện ảnh hưởng thị trường',NULL,'2026-08-29 08:31:11','2026-08-29 08:31:11'),(4,'Chiến lược','chien-luoc','Chiến lược giao dịch và quản lý vốn',NULL,'2026-08-29 08:31:11','2026-08-29 08:31:11'),(5,'Review Broker','review-broker','Đánh giá và so sánh các sàn giao dịch',NULL,'2026-08-29 08:31:11','2026-08-29 08:31:11');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ip_blocks`
--

DROP TABLE IF EXISTS `ip_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ip_blocks` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blocked_until` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip_address` (`ip_address`),
  KEY `idx_ip_until` (`ip_address`,`blocked_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip_blocks`
--

LOCK TABLES `ip_blocks` WRITE;
/*!40000 ALTER TABLE `ip_blocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip_blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_failures`
--

DROP TABLE IF EXISTS `login_failures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_failures` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `failed_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_ip_failed` (`ip_address`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_failures`
--

LOCK TABLES `login_failures` WRITE;
/*!40000 ALTER TABLE `login_failures` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_failures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `market_data_provider_config`
--

DROP TABLE IF EXISTS `market_data_provider_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `market_data_provider_config` (
  `provider_key` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` enum('forex','crypto','commodity','stock') COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  `requires_key` tinyint(1) NOT NULL DEFAULT '1',
  `api_key_encrypted` text COLLATE utf8mb4_unicode_ci,
  `api_secret_encrypted` text COLLATE utf8mb4_unicode_ci,
  `updated_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`provider_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `market_data_provider_config`
--

LOCK TABLES `market_data_provider_config` WRITE;
/*!40000 ALTER TABLE `market_data_provider_config` DISABLE KEYS */;
INSERT INTO `market_data_provider_config` VALUES ('alpaca','stock',1,1,NULL,NULL,NULL,'2026-08-29 08:31:14'),('coingecko','crypto',1,0,NULL,NULL,NULL,'2026-08-29 08:31:14'),('fcs','forex',1,1,NULL,NULL,NULL,'2026-08-29 08:31:14'),('goldapi','commodity',1,0,NULL,NULL,NULL,'2026-08-29 08:31:14'),('twelvedata','forex',1,1,NULL,NULL,NULL,'2026-08-29 08:31:14');
/*!40000 ALTER TABLE `market_data_provider_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `market_data_snapshots`
--

DROP TABLE IF EXISTS `market_data_snapshots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `market_data_snapshots` (
  `symbol_id` int unsigned NOT NULL,
  `price` decimal(18,6) NOT NULL,
  `change_percent` decimal(8,4) DEFAULT NULL,
  `direction` enum('up','down','flat') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'flat',
  `source` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fetched_at` timestamp NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`symbol_id`),
  CONSTRAINT `fk_market_data_snapshots_symbol` FOREIGN KEY (`symbol_id`) REFERENCES `market_data_symbols` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `market_data_snapshots`
--

LOCK TABLES `market_data_snapshots` WRITE;
/*!40000 ALTER TABLE `market_data_snapshots` DISABLE KEYS */;
INSERT INTO `market_data_snapshots` VALUES (1,1.086359,0.1992,'up','mock','2026-08-30 04:30:00','2026-08-30 04:30:00'),(2,1.263833,-0.2578,'down','mock','2026-08-30 04:30:00','2026-08-30 04:30:00'),(3,154.865004,-0.2929,'down','mock','2026-08-30 04:30:00','2026-08-30 04:30:00'),(4,0.903079,0.2086,'up','mock','2026-08-30 04:30:00','2026-08-30 04:30:00'),(5,0.659970,-0.2162,'down','mock','2026-08-30 04:30:00','2026-08-30 04:30:00'),(6,1.368370,-0.2646,'down','mock','2026-08-30 04:30:00','2026-08-30 04:30:00'),(7,0.602495,0.0324,'up','mock','2026-08-30 04:30:00','2026-08-30 04:30:00'),(8,2437.330094,-0.0316,'up','mock','2026-08-30 04:30:00','2026-08-30 04:30:00'),(9,29.053859,-0.2956,'down','mock','2026-08-30 04:30:00','2026-08-30 04:30:00'),(10,64314.884966,0.1555,'up','mock','2026-08-30 04:30:00','2026-08-30 04:30:00'),(11,3127.704614,0.2309,'up','mock','2026-08-30 04:30:00','2026-08-30 04:30:00'),(12,189.853412,0.1865,'down','mock','2026-08-30 04:30:00','2026-08-30 04:30:00'),(13,245.818591,-0.1955,'down','mock','2026-08-30 04:30:00','2026-08-30 04:30:00'),(14,414.482917,-0.1727,'down','mock','2026-08-30 04:30:00','2026-08-30 04:30:00');
/*!40000 ALTER TABLE `market_data_snapshots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `market_data_symbols`
--

DROP TABLE IF EXISTS `market_data_symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `market_data_symbols` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `label` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` enum('forex','crypto','commodity','stock') COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_codes` json NOT NULL,
  `decimals` tinyint unsigned NOT NULL DEFAULT '4',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `label` (`label`),
  KEY `idx_active_sort` (`is_active`,`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `market_data_symbols`
--

LOCK TABLES `market_data_symbols` WRITE;
/*!40000 ALTER TABLE `market_data_symbols` DISABLE KEYS */;
INSERT INTO `market_data_symbols` VALUES (1,'EUR/USD','forex','{\"fcs\": \"EURUSD\", \"twelvedata\": \"EUR/USD\"}',4,1,140,'2026-08-29 08:31:13','2026-08-29 08:31:13'),(2,'GBP/USD','forex','{\"fcs\": \"GBPUSD\", \"twelvedata\": \"GBP/USD\"}',4,1,130,'2026-08-29 08:31:13','2026-08-29 08:31:13'),(3,'USD/JPY','forex','{\"fcs\": \"USDJPY\", \"twelvedata\": \"USD/JPY\"}',2,1,120,'2026-08-29 08:31:13','2026-08-29 08:31:13'),(4,'USD/CHF','forex','{\"fcs\": \"USDCHF\", \"twelvedata\": \"USD/CHF\"}',4,1,100,'2026-08-29 08:31:13','2026-08-29 08:31:13'),(5,'AUD/USD','forex','{\"fcs\": \"AUDUSD\", \"twelvedata\": \"AUD/USD\"}',4,1,90,'2026-08-29 08:31:13','2026-08-29 08:31:13'),(6,'USD/CAD','forex','{\"fcs\": \"USDCAD\", \"twelvedata\": \"USD/CAD\"}',4,1,80,'2026-08-29 08:31:13','2026-08-29 08:31:13'),(7,'NZD/USD','forex','{\"fcs\": \"NZDUSD\", \"twelvedata\": \"NZD/USD\"}',4,1,70,'2026-08-29 08:31:13','2026-08-29 08:31:13'),(8,'XAU/USD','commodity','{\"goldapi\": \"XAU\"}',2,1,110,'2026-08-29 08:31:13','2026-08-29 08:31:13'),(9,'XAG/USD','commodity','{\"goldapi\": \"XAG\"}',2,1,60,'2026-08-29 08:31:13','2026-08-29 08:31:13'),(10,'BTC/USD','crypto','{\"coingecko\": \"bitcoin\"}',0,1,150,'2026-08-29 08:31:13','2026-08-29 08:31:13'),(11,'ETH/USD','crypto','{\"coingecko\": \"ethereum\"}',2,1,50,'2026-08-29 08:31:13','2026-08-29 08:31:13'),(12,'AAPL','stock','{\"alpaca\": \"AAPL\"}',2,1,40,'2026-08-29 08:31:13','2026-08-29 08:31:13'),(13,'TSLA','stock','{\"alpaca\": \"TSLA\"}',2,1,30,'2026-08-29 08:31:13','2026-08-29 08:31:13'),(14,'MSFT','stock','{\"alpaca\": \"MSFT\"}',2,1,20,'2026-08-29 08:31:13','2026-08-29 08:31:13');
/*!40000 ALTER TABLE `market_data_symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_tags`
--

DROP TABLE IF EXISTS `post_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post_tags` (
  `post_id` int unsigned NOT NULL,
  `tag_id` int unsigned NOT NULL,
  PRIMARY KEY (`post_id`,`tag_id`),
  KEY `tag_id` (`tag_id`),
  CONSTRAINT `post_tags_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `post_tags_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_tags`
--

LOCK TABLES `post_tags` WRITE;
/*!40000 ALTER TABLE `post_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_translations`
--

DROP TABLE IF EXISTS `post_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int unsigned NOT NULL,
  `locale` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `seo_title` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_desc` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('draft','published') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `source` enum('ai','human') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ai',
  `translated_by` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_post_locale` (`post_id`,`locale`),
  KEY `idx_status` (`status`),
  KEY `translated_by` (`translated_by`),
  CONSTRAINT `post_translations_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `post_translations_ibfk_2` FOREIGN KEY (`translated_by`) REFERENCES `admin_users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_translations`
--

LOCK TABLES `post_translations` WRITE;
/*!40000 ALTER TABLE `post_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(280) COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `featured_image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_id` int unsigned NOT NULL,
  `category_id` int unsigned DEFAULT NULL,
  `status` enum('draft','published','archived') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int NOT NULL DEFAULT '0',
  `view_count` int unsigned NOT NULL DEFAULT '0',
  `read_time` smallint unsigned DEFAULT NULL,
  `seo_title` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_desc` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_slug` (`slug`),
  KEY `idx_author` (`author_id`),
  KEY `idx_category` (`category_id`),
  KEY `idx_status_published` (`status`,`published_at`),
  KEY `idx_featured` (`is_featured`),
  KEY `idx_sort_order` (`sort_order`),
  FULLTEXT KEY `idx_search` (`title`,`excerpt`,`content`),
  CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `admin_users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `posts_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (1,'Forex là gì? Hướng dẫn cho người mới bắt đầu từ A-Z','forex-la-gi-huong-dan-cho-nguoi-moi-bat-dau','Tổng quan về thị trường forex, cách hoạt động và những khái niệm cơ bản nhất trader mới cần nắm.','<p>Forex (foreign exchange) là thị trường giao dịch ngoại hối lớn nhất thế giới...</p>',NULL,1,1,'published',1,1,4,12,NULL,NULL,'2026-07-24 08:00:00','2026-08-29 08:31:11','2026-08-29 09:07:15'),(2,'Cách đọc mô hình nến Nhật trong giao dịch ngắn hạn','cach-doc-mo-hinh-nen-nhat-trong-giao-dich-ngan-han','Hướng dẫn nhận diện các mô hình nến phổ biến và ứng dụng trong phân tích kỹ thuật ngắn hạn.','<p>Mô hình nến Nhật (candlestick pattern) là công cụ phân tích kỹ thuật lâu đời...</p>',NULL,1,2,'published',1,2,4,9,NULL,NULL,'2026-07-22 08:00:00','2026-08-29 08:31:11','2026-08-29 09:07:14'),(3,'Fed giữ nguyên lãi suất: điều gì chờ đợi USD trong quý tới?','fed-giu-nguyen-lai-suat-dieu-gi-cho-doi-usd-trong-quy-toi','Phân tích tác động của quyết định lãi suất Fed lên đồng USD và các cặp tiền chính.','<p>Cục Dự trữ Liên bang Mỹ (Fed) vừa công bố giữ nguyên lãi suất...</p>',NULL,1,3,'published',1,3,4,6,NULL,NULL,'2026-07-21 08:00:00','2026-08-29 08:31:11','2026-08-29 09:07:12'),(4,'5 chiến lược quản lý vốn giúp trader tồn tại lâu dài','5-chien-luoc-quan-ly-von-giup-trader-ton-tai-lau-dai','Quản lý vốn là yếu tố quyết định sự sống còn của trader hơn cả chiến lược vào lệnh.','<p>Nhiều trader thất bại không phải vì chiến lược vào lệnh kém, mà vì quản lý vốn sai...</p>',NULL,1,4,'published',0,4,4,11,NULL,NULL,'2026-07-19 08:00:00','2026-08-29 08:31:11','2026-08-29 09:07:15'),(5,'So sánh chi tiết IC Markets và XM: nên chọn sàn nào?','so-sanh-chi-tiet-ic-markets-va-xm-nen-chon-san-nao','So sánh spread, đòn bẩy, nạp rút và độ tin cậy giữa hai sàn phổ biến IC Markets và XM.','<p>IC Markets và XM đều là những lựa chọn phổ biến, nhưng phù hợp với nhóm trader khác nhau...</p>',NULL,1,5,'published',0,5,4,8,NULL,NULL,'2026-07-17 08:00:00','2026-08-29 08:31:11','2026-08-29 09:07:11'),(6,'Đòn bẩy và margin call: hiểu đúng để tránh cháy tài khoản','don-bay-va-margin-call-hieu-dung-de-tranh-chay-tai-khoan','Giải thích cơ chế đòn bẩy, margin call và cách quản lý rủi ro để tránh mất trắng tài khoản.','<p>Đòn bẩy (leverage) là con dao hai lưỡi trong giao dịch forex...</p>',NULL,1,1,'published',0,6,4,7,NULL,NULL,'2026-07-15 08:00:00','2026-08-29 08:31:11','2026-08-29 09:07:14');
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_changelog`
--

DROP TABLE IF EXISTS `schema_changelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schema_changelog` (
  `version` varchar(50) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `checksum` varchar(64) NOT NULL,
  `applied_by` varchar(100) NOT NULL,
  `applied_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`version`,`filename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_changelog`
--

LOCK TABLES `schema_changelog` WRITE;
/*!40000 ALTER TABLE `schema_changelog` DISABLE KEYS */;
INSERT INTO `schema_changelog` VALUES ('001_init','001_create_core_tables.sql','create core tables','c146293ff06ebb38ac25802a8dc22d3750bffeb24cfc7986b75fd9100683af0f','root','2026-08-29 08:31:06'),('001_logging','001_create_system_logs.sql','create system logs','a04fc87db165401f4064bae0bcca36e133786a77247fb8ca0bd237610f4686f5','root','2026-08-29 08:31:07'),('002_settings','001_create_site_settings.sql','create site settings','3cc6920a3deaf50a05897fe9d6028da3c207439b6442c459e3d90355bb0b3dc3','root','2026-08-29 08:31:07'),('003_audit','001_create_admin_audit_log.sql','create admin audit log','6f07e5264e4ab0a05b2288b8c440636c69b141a9c1906562bbe1ba1be52ca067','root','2026-08-29 08:31:08'),('004_security','001_create_security_tables.sql','create security tables','a8c5bc20a0afc6f7fd279a25e1022be122930666fdb1b150e493813a87be2917','root','2026-08-29 08:31:08'),('005_seed_admin','001_seed_admin_user.sql','seed admin user','bc4863f3aa4b1dece5a68564416b4e02e227d233d7570ccfcb1db761e1a0e685','root','2026-08-29 08:31:09'),('006_business','001_alter_posts_brokers.sql','alter posts brokers','0480565d9de316e3222690868c2a1938dab938a318688058eb16af1afb5bbc75','root','2026-08-29 08:31:10'),('006_business','002_create_subscribers.sql','create subscribers','85ddd5801dc66219999b93318cb73b0ce3340b425bf109a40fdd38cd66cb517f','root','2026-08-29 08:31:10'),('006_business','003_seed_content.sql','seed content','a1e035a8476a04b849eb1c5eb7934e58102b3cd709998267ae62acb3834df8f3','root','2026-08-29 08:31:11'),('007_design_refresh','001_update_theme_signal.sql','update theme signal','71668822f95824fadda0976118832722d5d73d66de4cf7b1a4fd14abfeb9a04b','root','2026-08-29 08:31:11'),('008_content_ranking','001_add_sort_order.sql','add sort order','6dd6015e6a41ba72c6d8fcce4f9006e42c5728c0915a5257de8a6a3379f1ad44','root','2026-08-29 08:31:12'),('008_content_ranking','002_backfill_sort_order.sql','backfill sort order','e05b7b4c10987ce5b18ea6cea1ce6b2fb8a4689f50f1ede729114c6c4caa3c24','root','2026-08-29 08:31:12'),('009_market_data','001_create_market_data_tables.sql','create market data tables','db6b90107ca9f4794fb288238a99457834c74a528b362e861a9950d0d4abbfdb','root','2026-08-29 08:31:13'),('009_market_data','002_seed_symbols.sql','seed symbols','4248bb726dfe027ce155a007a7760024cc1157807652466a5d2c7a01e9ec0a7c','root','2026-08-29 08:31:13'),('010_background_images','001_add_background_settings.sql','add background settings','e072e4979fd6db1cc2f139605b171932e55834e3237467ea76b84327fcd0b5f1','root','2026-08-29 08:31:14'),('011_post_translations','001_create_post_translations.sql','create post translations','f50ce493d815f56c140dddfd039a5595d1a380cee4a074d308bde74c8ab51356','root','2026-08-29 08:31:14'),('012_market_data_provider_config','001_create_market_data_provider_config.sql','create market data provider config','5bcc857f7cba42284d421c68a0357b6e820d3145f224fb1afcd1de42b50f1f95','root','2026-08-29 08:31:14');
/*!40000 ALTER TABLE `schema_changelog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_settings`
--

DROP TABLE IF EXISTS `site_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_settings` (
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text NOT NULL,
  `value_type` enum('color','boolean','text','number','image') NOT NULL DEFAULT 'text',
  `category` varchar(50) NOT NULL,
  `updated_by` varchar(50) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_key`),
  KEY `idx_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_settings`
--

LOCK TABLES `site_settings` WRITE;
/*!40000 ALTER TABLE `site_settings` DISABLE KEYS */;
INSERT INTO `site_settings` VALUES ('bg.global','','image','background','1','2026-08-29 09:29:10'),('bg.hero','','image','background','1','2026-08-29 08:41:28'),('bg.newsletter','','image','background','1','2026-08-29 08:41:28'),('bg.ticker','','image','background','1','2026-08-29 08:41:28'),('layout.hero_variant','editorial','text','layout','1','2026-08-29 08:41:00'),('layout.show_ticker','true','boolean','layout','1','2026-08-29 08:41:00'),('layout.site_name','PIPSNOTE','text','layout','1','2026-08-29 08:41:00'),('theme.bg','#0A0F1A','color','theme','1','2026-08-29 09:33:32'),('theme.dark_default','true','boolean','theme','1','2026-08-29 08:41:00'),('theme.down','#EF4444','color','theme','1','2026-08-29 09:33:32'),('theme.gray_bg','#111826','color','theme','1','2026-08-29 09:33:32'),('theme.gray_line','#22304A','color','theme','1','2026-08-29 09:33:32'),('theme.gray_mid','#7C8BA8','color','theme','1','2026-08-29 09:33:32'),('theme.ink','#E6EEF7','color','theme','1','2026-08-29 09:33:32'),('theme.red','#2E8BFF','color','theme','1','2026-08-29 09:33:32'),('theme.red_dark','#1D63C9','color','theme','1','2026-08-29 09:33:32'),('theme.surface_dark','#05080F','color','theme','1','2026-08-29 09:33:32'),('theme.up','#22C55E','color','theme','1','2026-08-29 09:33:32');
/*!40000 ALTER TABLE `site_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscribers`
--

DROP TABLE IF EXISTS `subscribers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscribers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('active','unsubscribed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `source` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscribers`
--

LOCK TABLES `subscribers` WRITE;
/*!40000 ALTER TABLE `subscribers` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscribers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_logs`
--

DROP TABLE IF EXISTS `system_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `level` enum('debug','info','warn','error','fatal') COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `stacktrace` text COLLATE utf8mb4_unicode_ci,
  `module` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int unsigned DEFAULT NULL,
  `url` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `method` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_code` int DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_level_created` (`level`,`created_at`),
  KEY `idx_module` (`module`),
  KEY `idx_request_id` (`request_id`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_logs`
--

LOCK TABLES `system_logs` WRITE;
/*!40000 ALTER TABLE `system_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'pipsnote'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-30  4:39:20
